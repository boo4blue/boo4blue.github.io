ONION CORE SFX VAULT VOL. 1 — game-ready sound effects
========================================================
CONTENTS
- sfx/ : 20 synthesized WAVs (44.1 kHz, 16-bit, mono, peak-normalized to 0.89)
  UI x4 (click, confirm, back, error) - Player x3 (jump, land, hurt)
  Pickup x3 (coin, powerup, sparkle) - Combat x5 (explosion, hit, swing, zap, shot)
  Vehicle x2 (boost, crash) - Loops x3 (engine 2s seamless, menu music 8.6s, tension 5.3s)
- bonus-racing-sfx/ : 16 racing WAVs from Death Cart 3D (22.05 kHz mono):
  beep, boost, breakdown, click, drift, engine, explosion, finish, go, hit,
  pickup, rocket, shoot, spin, wall, wrench
- preview-oneshots.mp3 : every one-shot back-to-back, hear before you import
- manifest.json : name / category / description / duration for every library sound

Every sound was synthesized from scratch in-house — no samples, no third-party
audio, no licensing traps. Drop the WAVs straight into Godot / Unity / Unreal /
GameMaker; set loop mode = Forward on the three loops.

Made by Blaze / Onion Core.
