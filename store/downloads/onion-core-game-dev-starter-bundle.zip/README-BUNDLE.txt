ONION CORE GAME DEV STARTER BUNDLE
====================================

All three Onion Core Vol. 1 packs in one download:

1. SFX Vault Vol. 1 - 36 game-ready sound effects (WAV)
2. Seamless PBR Textures Vol. 1 - 8 tileable materials, full PBR sets
3. Loops, Beats & Drum Kit - game music starter pack

Each pack is its own ZIP inside this bundle, with its own README and
LICENSE (use in your own projects, commercial OK; no redistribution
of the raw packs).

- Onion Core
