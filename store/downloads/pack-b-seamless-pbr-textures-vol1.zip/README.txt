SEAMLESS PBR TEXTURES VOL. 1 — 8 materials, full PBR sets
============================================================
8 materials x (albedo + normal + roughness + height) = 32 maps, 512x512 PNG,
plus a 2x2-tiled preview for every material so you can judge the seams
(they tile perfectly — generated tileable-by-construction, normals from
wrapped-gradient height so relief is seamless too).

MATERIALS: stone tiles, brick, wood planks, grass, asphalt, dirt,
metal plate, sand.

USE: Godot StandardMaterial3D (albedo + normal_enabled + roughness_texture,
texture_repeat on), Unity URP/HDRP, Unreal, Blender. Normal maps use the
OpenGL / Godot green-up convention (flip green for DirectX engines).

Procedurally generated in-house — no photos, no third-party textures.

Made by Blaze / Onion Core.
