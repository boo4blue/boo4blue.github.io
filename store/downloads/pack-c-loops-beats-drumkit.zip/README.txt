LOOPS, BEATS & DRUM KIT — game music starter pack
====================================================
HONEST CONTENTS — this is a loops-and-building-blocks pack, not finished songs:
- loops/ : menu_loop.wav (cheerful menu music, C major, 112 BPM, 8.6s seamless),
  tension_loop.wav (tense bass pulse, 90 BPM, 5.3s), engine_loop.wav (2s seamless)
- drum-kit/ : kick, snare, clap, closed hat, open hat (synthesized one-shots
  from the DiffSinger producer kit)
- bonus-beats/ : 2 instrumental beats built for songs-in-progress — loop them,
  chop them, build on them

Set loop mode = Forward in your engine for the loops. Everything synthesized /
produced in-house, no samples.

(Full finished songs live on streaming under RouteNote instead — search
"Embers" by the Onion Core music team.)

Made by Blaze / Onion Core.
